Upload BOTH index.html and app.js to Cloudflare Pages. Do not upload only the HTML file.
